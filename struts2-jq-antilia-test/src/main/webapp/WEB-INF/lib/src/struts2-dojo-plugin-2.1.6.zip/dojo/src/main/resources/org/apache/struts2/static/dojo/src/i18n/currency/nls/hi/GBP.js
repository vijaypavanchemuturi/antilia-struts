/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"displayName":"\u092c\u094d\u0930\u093f\u0924\u0928 \u0915\u093e \u092a\u094c\u0928\u094d\u0921 \u0938\u094d\u091f\u0930\u094d\u0932\u093f\u0917", "symbol":"\xa3"})