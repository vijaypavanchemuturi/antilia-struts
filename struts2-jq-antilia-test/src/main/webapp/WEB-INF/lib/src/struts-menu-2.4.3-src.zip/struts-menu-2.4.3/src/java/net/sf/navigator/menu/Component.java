package net.sf.navigator.menu;

/**
 * @author DEPeart
 *
 */
public interface Component {
    String getName();
    void setName(String name);
}
