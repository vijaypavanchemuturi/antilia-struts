package net.sf.navigator.menu;

/**
 * @author DEPeart
 *
 */
public interface Repository {

}
